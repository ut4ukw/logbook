To compile this demo, you'll need Tnt Unicode Controls:
http://www.yunqa.de
