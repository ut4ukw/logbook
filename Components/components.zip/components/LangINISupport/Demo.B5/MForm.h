//---------------------------------------------------------------------------

#ifndef MFormH
#define MFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "LngINISupp.hpp"
#include "MsgINISupp.hpp"
#include <Menus.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <ImgList.hpp>
#include <ToolWin.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
#include <ExtDlgs.hpp>
//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:	// IDE-managed Components
        TLngINISupp *LIS;
        TMsgINISupp *MIS;
        TMainMenu *MM;
        TPopupMenu *PM;
        TMenuItem *File1;
        TMenuItem *Exit1;
        TMenuItem *Save1;
        TMenuItem *Open1;
        TMenuItem *Edit1;
        TMenuItem *Object1;
        TMenuItem *Links1;
        TMenuItem *N3;
        TMenuItem *GoTo1;
        TMenuItem *Replace1;
        TMenuItem *Find1;
        TMenuItem *N4;
        TMenuItem *PasteSpecial1;
        TMenuItem *Paste1;
        TMenuItem *Copy1;
        TMenuItem *Cut1;
        TMenuItem *N5;
        TMenuItem *Repeatcommand1;
        TMenuItem *Undo1;
        TMenuItem *Help1;
        TMenuItem *About1;
        TMenuItem *HowtoUseHelp1;
        TMenuItem *SearchforHelpOn1;
        TMenuItem *Contents1;
        TMenuItem *OpenPicture1;
        TMenuItem *SavePicture1;
        TMenuItem *Paste2;
        TMenuItem *Copy2;
        TMenuItem *Cut2;
        TStatusBar *StatusBar1;
        TToolBar *ToolBar1;
        TImageList *ImageList1;
        TToolButton *ToolButton1;
        TToolButton *ToolButton2;
        TToolButton *ToolButton3;
        TToolButton *ToolButton4;
        TToolButton *ToolButton5;
        TToolButton *ToolButton6;
        TToolButton *ToolButton7;
        TToolButton *ToolButton8;
        TToolButton *ToolButton9;
        TToolButton *ToolButton10;
        TToolButton *ToolButton11;
        TPanel *Panel1;
        TPageControl *PageControl1;
        TTabSheet *TabSheet1;
        TTabSheet *TabSheet2;
        TTabSheet *TabSheet3;
        TTabSheet *TabSheet4;
        TCheckBox *CheckBox1;
        TCheckBox *CheckBox2;
        TCheckBox *CheckBox3;
        TRadioButton *RadioButton1;
        TRadioButton *RadioButton2;
        TRadioButton *RadioButton3;
        TGroupBox *GroupBox1;
        TGroupBox *GroupBox2;
        TRadioGroup *RadioGroup1;
        TRadioGroup *RadioGroup2;
        TPanel *Panel3;
        TPanel *Panel4;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TEdit *Edit4;
        TEdit *Edit3;
        TEdit *Edit2;
        TSpeedButton *SpeedButton1;
        TSpeedButton *SpeedButton3;
        TSpeedButton *SpeedButton4;
        TSpeedButton *SpeedButton2;
        TButton *Button1;
        TBitBtn *BitBtn1;
        TStaticText *StaticText1;
        TButton *Button3;
        TButton *Button2;
        TSavePictureDialog *SavePictureDialog1;
        TOpenPictureDialog *OpenPictureDialog1;
        TSaveDialog *SaveDialog1;
        TOpenDialog *OpenDialog1;
        void __fastcall FormShow(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall Open1Click(TObject *Sender);
        void __fastcall Save1Click(TObject *Sender);
        void __fastcall OpenPicture1Click(TObject *Sender);
        void __fastcall SavePicture1Click(TObject *Sender);
        void __fastcall Exit1Click(TObject *Sender);
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall Button3Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TMainForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
