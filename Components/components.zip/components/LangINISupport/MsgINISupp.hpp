// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'MsgINISupp.pas' rev: 5.00

#ifndef MsgINISuppHPP
#define MsgINISuppHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <LngINISupp.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <IniFiles.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Msginisupp
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TMsgINISupp;
class PASCALIMPLEMENTATION TMsgINISupp : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	AnsiString FFileName;
	Lnginisupp::TLngINISupp* FLngINISupp;
	void __fastcall SetFileName(const AnsiString Value);
	void __fastcall SetLngINISupp(const Lnginisupp::TLngINISupp* Value);
	void __fastcall CheckFile(AnsiString FN);
	
public:
	void __fastcall Open(void);
	void __fastcall Close(void);
	AnsiString __fastcall GetMsg(AnsiString MsgName);
	
__published:
	__property AnsiString FileName = {read=FFileName, write=SetFileName};
	__property Lnginisupp::TLngINISupp* LngINISupp = {read=FLngINISupp, write=SetLngINISupp};
public:
	#pragma option push -w-inl
	/* TComponent.Create */ inline __fastcall virtual TMsgINISupp(Classes::TComponent* AOwner) : Classes::TComponent(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TComponent.Destroy */ inline __fastcall virtual ~TMsgINISupp(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE Inifiles::TIniFile* AppIniMsg;
extern PACKAGE Classes::TStrings* Values;
extern PACKAGE BOOL FNF;
extern PACKAGE BOOL FNP;
extern PACKAGE BOOL Opened;
extern PACKAGE void __fastcall Register(void);

}	/* namespace Msginisupp */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Msginisupp;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// MsgINISupp
