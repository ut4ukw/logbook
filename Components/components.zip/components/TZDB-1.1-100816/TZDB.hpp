// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Tzdb.pas' rev: 21.00

#ifndef TzdbHPP
#define TzdbHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Timespan.hpp>	// Pascal unit
#include <Dateutils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Math.hpp>	// Pascal unit
#include <Types.hpp>	// Pascal unit
#include <Generics.collections.hpp>	// Pascal unit
#include <Generics.defaults.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Tzdb
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TLocalTimeType { lttStandard, lttDaylight, lttAmbiguous, lttInvalid };
#pragma option pop

class DELPHICLASS TTimeZone;
class PASCALIMPLEMENTATION TTimeZone : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	static TTimeZone* FLocal;
	
private:
	/* __classmethod void __fastcall Create@() */;
	/* __classmethod void __fastcall Destroy@() */;
	
private:
	System::UnicodeString __fastcall GetAbbreviationForNow(void);
	System::UnicodeString __fastcall GetDisplayNameForNow(void);
	__int64 __fastcall GetUtcOffsetInSeconds(const System::TDateTime ADateTime, const bool ForceDaylight);
	Timespan::TTimeSpan __fastcall GetCurrentUtcOffset(void);
	
protected:
	virtual void __fastcall DoGetOffsetsAndType(const System::TDateTime ADateTime, /* out */ __int64 &AOffset, /* out */ __int64 &ADstSave, /* out */ TLocalTimeType &AType) = 0 ;
	virtual System::UnicodeString __fastcall DoGetDisplayName(const System::TDateTime ADateTime, const bool ForceDaylight) = 0 ;
	virtual System::UnicodeString __fastcall DoGetID(void) = 0 ;
	
public:
	Timespan::TTimeSpan __fastcall GetUtcOffset(const System::TDateTime ADateTime, const bool ForceDaylight = false);
	System::TDateTime __fastcall ToUniversalTime(const System::TDateTime ADateTime, const bool ForceDaylight = false);
	System::TDateTime __fastcall ToLocalTime(const System::TDateTime ADateTime);
	System::UnicodeString __fastcall GetDisplayName(const System::TDateTime ADateTime, const bool ForceDaylight = false);
	System::UnicodeString __fastcall GetAbbreviation(const System::TDateTime ADateTime, const bool ForceDaylight = false);
	TLocalTimeType __fastcall GetLocalTimeType(const System::TDateTime ADateTime);
	bool __fastcall IsStandardTime(const System::TDateTime ADateTime, const bool ForceDaylight = false);
	bool __fastcall IsInvalidTime(const System::TDateTime ADateTime);
	bool __fastcall IsAmbiguousTime(const System::TDateTime ADateTime);
	bool __fastcall IsDaylightTime(const System::TDateTime ADateTime, const bool ForceDaylight = false);
	__property System::UnicodeString ID = {read=DoGetID};
	__property System::UnicodeString DisplayName = {read=GetDisplayNameForNow};
	__property System::UnicodeString Abbreviation = {read=GetAbbreviationForNow};
	__property Timespan::TTimeSpan UtcOffset = {read=GetCurrentUtcOffset};
	/* static */ __property TTimeZone* Local = {read=FLocal};
public:
	/* TObject.Create */ inline __fastcall TTimeZone(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TTimeZone(void) { }
	
};


class DELPHICLASS ETimeZoneInvalid;
class PASCALIMPLEMENTATION ETimeZoneInvalid : public Sysutils::Exception
{
	typedef Sysutils::Exception inherited;
	
public:
	/* Exception.Create */ inline __fastcall ETimeZoneInvalid(const System::UnicodeString Msg) : Sysutils::Exception(Msg) { }
	/* Exception.CreateFmt */ inline __fastcall ETimeZoneInvalid(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	/* Exception.CreateRes */ inline __fastcall ETimeZoneInvalid(int Ident)/* overload */ : Sysutils::Exception(Ident) { }
	/* Exception.CreateResFmt */ inline __fastcall ETimeZoneInvalid(int Ident, System::TVarRec const *Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	/* Exception.CreateHelp */ inline __fastcall ETimeZoneInvalid(const System::UnicodeString Msg, int AHelpContext) : Sysutils::Exception(Msg, AHelpContext) { }
	/* Exception.CreateFmtHelp */ inline __fastcall ETimeZoneInvalid(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext) { }
	/* Exception.CreateResHelp */ inline __fastcall ETimeZoneInvalid(int Ident, int AHelpContext)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	/* Exception.CreateResFmtHelp */ inline __fastcall ETimeZoneInvalid(System::PResStringRec ResStringRec, System::TVarRec const *Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	/* Exception.Destroy */ inline __fastcall virtual ~ETimeZoneInvalid(void) { }
	
};


class DELPHICLASS TBundledTimeZone;
class PASCALIMPLEMENTATION TBundledTimeZone : public TTimeZone
{
	typedef TTimeZone inherited;
	
private:
	static Generics_collections::TObjectDictionary__2<System::UnicodeString,TTimeZone*>* FCache;
	void *FZone;
	Generics_collections::TObjectList__1<System::TObject*>* FPeriods;
	void __fastcall CompilePeriods(void);
	bool __fastcall GetPeriodAndRule(const System::TDateTime ADateTime, /* out */ System::TObject* &APeriod, /* out */ System::TObject* &ARule);
	void __fastcall GetTZData(const System::TDateTime ADateTime, /* out */ __int64 &AOffset, /* out */ __int64 &ADstSave, /* out */ TLocalTimeType &AType, /* out */ System::UnicodeString &ADisplayName, /* out */ System::UnicodeString &ADstDisplayName);
	
protected:
	virtual void __fastcall DoGetOffsetsAndType(const System::TDateTime ADateTime, /* out */ __int64 &AOffset, /* out */ __int64 &ADstSave, /* out */ TLocalTimeType &AType);
	virtual System::UnicodeString __fastcall DoGetDisplayName(const System::TDateTime ADateTime, const bool ForceDaylight);
	virtual System::UnicodeString __fastcall DoGetID(void);
	
public:
	__fastcall TBundledTimeZone(const System::UnicodeString ATimeZoneID);
	__fastcall virtual ~TBundledTimeZone(void);
	static System::TArray__1<System::UnicodeString>  __fastcall KnownTimeZones(const bool AIncludeAliases = false);
	static TTimeZone* __fastcall GetTimeZone(const System::UnicodeString ATimeZoneID);
};


typedef void *TTimeZoneHelper;

//-- var, const, procedure ---------------------------------------------------

}	/* namespace Tzdb */
using namespace Tzdb;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// TzdbHPP
