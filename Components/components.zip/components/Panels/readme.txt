TDynPanel works similar to the interface mechanism used in 3D Studio Max.
Based on a TPanel it can be used to manage large amounts of controls in
collapsable and dragable panels. TDynPanel is aware of other TDynPanels
in the same Parent and will realign other TDynPanels when it collapses
or expands provided the other TDynPanels have the same Left and Width.
TDynPanel is also dragable in vertical direction and will drag other
TDynPanels along provided the other TDynPanels have the same Left and
Width values.
The result is a 3DStudio lookalike Collapsable and dragable interface
that can be created without a single line of code!

Derived and enhaced from Paul van Dinther's original TSchrinkPanel,
with bugs fixed and improvements.
Added cursors: open hand when is dragable, closed hand while draging
and default when it can't be draged.
I have made this modifications quickly and may have things to
correct/improve or omissions, but I used and it works good.

Alejandro B. <ale_x@uol.com.ar>  11/10/2001