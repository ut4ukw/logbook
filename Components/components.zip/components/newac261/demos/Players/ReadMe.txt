This folder contains demos that show how to play diferent audio files with NewAC.
Following is the short description of each demo:

� APEPlayer - the Monkey Audio player.

� AudioPlayer - this player can play several formats (wav, mp3, og, flac). It also shows how to buuild simple  playlists.

� CDPlayer � this is program that turns your CD-drive into a CD-DA player. Note, it works only with drives that support native CD-DA playback. 

� i-Radio - mp3/WMA live audio player.

� FLACPlayer � the FLAC format payer that shows FLAC tags.

� MP3Player � the mp3 payer that shows mp3 tags.

� NetworkRadioStation � simple network audio broadcasting station.

� NetworkRadioStation-2 � simple network audio broadcasting station that uses a gapless mp3 playlist (TAudioPlayList component).

� OggPlayer � the Ogg Vorbis format payer that shows Vorbis tags and the current bitrate.

� WMPlayer � the Windows Media Audio (WMA) payer that shows Id3V2 tags.

� WVPlayer � the WavPack format payer that shows Id2V2 tags.