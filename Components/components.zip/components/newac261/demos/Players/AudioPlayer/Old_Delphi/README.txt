This demo shows how to play different audio formats and how to construct simple playlists.
You will need all dlls NewAC depends on to run this demo.
In the playlist you may click a song name and player will switch to that song.