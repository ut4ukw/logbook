This folder contains some demos that teach special aspects of working with NewAC. 
Following is the short description of each demo:

� ComponentsDemo - this well commented demo shows how to write your own input and output components.

� AudioProcessor - this demo shows how to use TAudioProcessor component for your own sound-processing tasks. 