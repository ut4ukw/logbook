This folder contains demos that show how to record sound from sound cards or rip CDs. 
Following is the short description of each demo:

� CDRipper - the name stays for itself. This demo can store rips in wav, ogg, and flac formats.

� DirectSoundRecorder - this demo shows how to record sound from a sound card. Can store records in several formats.

� RadioRecorder - this demo shows how you can record live Internt broadcasts. 

� Rip'n'listen - CD ripper that allows you listen to the track you are ripping. This ripper can store rips in wav, ogg, flac, and wma formats.
